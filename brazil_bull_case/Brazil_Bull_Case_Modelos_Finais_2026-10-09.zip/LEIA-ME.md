# Brazil Bull Case: modelos finais (9/out/2026)

Preços de 5/out/2026 (Ibovespa 208.432). Os números ainda passam pelo Fernando e pelo compliance antes de ir para clientes.

## Arquivos

| Pasta | Arquivo | O que é | Bear / base / bull |
|---|---|---|---|
| DCF by box | Financials_DCF_XP.xlsx | DDM de banco, ROE de 2028 constante | −34 / −6 / +19% |
| DCF by box | Defensives_DCF_XP.xlsx | Utilities + resto; margem dos analistas; capex dos analistas nas utilities e de consenso no resto; sem arrendamentos | −20 / +10 / +35% |
| DCF by box | Cyclicals_DCF_XP.xlsx | WEG & Embraer + resto; margem dos analistas, capex de consenso | −27 / +13 / +54% |
| DCF by box | Commodities_DCF_XP.xlsx | Lucro cresce com a inflação a partir de 2029 | −33 / +11 / +55% |
| Multiples and bottom-up | Ibov_Multiples_BottomUp_XP.xlsx | P/L e EV/EBITDA (média de 10 anos ±1 desvio) e bottom-up (Ke ±200 bp), agora com a sensibilidade a Ke dos analistas de Real Estate | Ibov −16 / +10 / +41% |
| Ibovespa | Ibov_DCF_SOTP_XP.xlsx | DCF do Ibovespa como soma das 4 caixinhas | −29 / +6 / +39% |
| Ibovespa | Ibov_Valuation_Master_XP.xlsx | Todos os métodos × caixinhas, visão por método e por caixinha, ponte para o DCF da casa | média −20 / +9 / +41% |

## Premissas comuns dos DCFs

- **Ke:** (NTN-B 5 anos + IPCA 4%) × 0,85 + beta da caixinha (semanal, 10 anos) × ERP 5,5%.
- **Consenso:** Bloomberg BEst de 2026–28.
- **Horizonte:** 8 anos explícitos (2028–35); Gordon sobre o último fluxo, sem período extra.
- **Capital de giro:** 4% da variação da receita.
- **Cenários:**
  - juro real de 8,5% / 6,76% / 6,0%;
  - choque de lucro de −20% / 0 / +20% × o beta de lucro de cada caixinha (em Commodities, choque de preço × elasticidade 1,26).

## Observações

- **Origem dos DCFs de Financials, Cíclicos e Commodities:** são cópias das versões em que trabalhamos no OneDrive. Os scripts `build_client_*.py` desses três ainda não refletem todos os ajustes de 9/out (bull de 6%, ROE de 2028, capex de consenso em Cíclicos, crescimento de Commodities). Se for regerar, use estes arquivos como referência.
- **Bull nos múltiplos vs. no DCF:** os múltiplos usam Selic de 9,5% (juro real de 5,5%), e os DCFs usam juro real de 6%.
