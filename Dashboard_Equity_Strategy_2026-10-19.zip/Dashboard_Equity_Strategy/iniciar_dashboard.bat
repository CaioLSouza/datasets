@echo off
rem Abre o dashboard: sobe o servidor local e o navegador. Feche esta janela para encerrar.
cd /d "%~dp0"
where py >nul 2>nul && (py -3 servidor.py %* & goto :eof)
where python >nul 2>nul && (python servidor.py %* & goto :eof)
echo Python nao encontrado neste computador.
echo Instale o Python 3 (python.org, marque "Add python.exe to PATH") e rode este arquivo de novo.
pause
