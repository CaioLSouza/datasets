"""Servidor local do dashboard (cópia portátil).

Serve a pasta site/ e a rota /api/live (cotações do Yahoo Finance, ~15 min de atraso).
Não precisa de nenhum pacote além do Python 3.9+.

Uso: python servidor.py [porta] [--sem-navegador]
"""
from __future__ import annotations

import json
import socket
import sys
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

SITE = Path(__file__).resolve().parent / "site"
YAHOO = "https://query1.finance.yahoo.com/v8/finance/chart/{}"
HEADERS = {"User-Agent": "Mozilla/5.0"}
CACHE_SECONDS = 60
# Índices sem série no Yahoo usam um ETF como aproximação
SYMBOL_MAP = {"Ibovespa": "^BVSP", "SMLL": "SMAL11.SA"}
_cache: dict = {}


def _yahoo_symbol(s: str) -> str:
    return SYMBOL_MAP.get(s, s if s.startswith("^") or "." in s else f"{s}.SA")


def _get_json(url: str, params: dict) -> dict:
    req = urllib.request.Request(url + "?" + urllib.parse.urlencode(params), headers=HEADERS)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def quote(symbol: str, asof: str):
    key = (symbol, asof)
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < CACHE_SECONDS:
        return hit[1]
    try:
        res = _get_json(YAHOO.format(urllib.parse.quote(_yahoo_symbol(symbol))), {"range": "1mo", "interval": "1d"})["chart"]["result"][0]
        meta = res["meta"]
        closes = res["indicators"]["quote"][0]["close"]
        days = [datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%d") for t in res["timestamp"]]
        ref = next((c for d, c in reversed(list(zip(days, closes))) if d <= asof and c is not None), None)
        price = meta.get("regularMarketPrice")
        # pregão que já está nos fechamentos do site: o retorno do dia não pode contar duas vezes
        qday = (datetime.fromtimestamp(meta["regularMarketTime"], timezone.utc) - timedelta(hours=3)).strftime("%Y-%m-%d") if meta.get("regularMarketTime") else ""
        if qday and qday <= asof:
            ref = price
        out = {
            "price": price,
            "ref_close": ref,
            "ret": (price / ref - 1) if (price and ref) else None,
            "time": meta.get("regularMarketTime"),
            "proxy": SYMBOL_MAP.get(symbol) if symbol in SYMBOL_MAP and "." in SYMBOL_MAP[symbol] else None,
        }
    except Exception:
        out = None
    _cache[key] = (time.time(), out)
    return out


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(SITE), **kw)

    def do_GET(self):  # noqa: N802
        url = urllib.parse.urlparse(self.path)
        if url.path != "/api/live":
            return super().do_GET()
        q = urllib.parse.parse_qs(url.query)
        symbols = [s for s in q.get("symbols", [""])[0].split(",") if s][:120]
        asof = q.get("asof", [""])[0]
        with ThreadPoolExecutor(max_workers=12) as ex:
            quotes = dict(zip(symbols, ex.map(lambda s: quote(s, asof), symbols)))
        body = json.dumps({"asof": asof, "quotes": quotes}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def end_headers(self):
        if urllib.parse.urlparse(self.path).path != "/api/live":
            self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def log_message(self, *args):
        pass


def _porta_livre(inicial: int) -> int:
    for p in range(inicial, inicial + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    raise SystemExit("Nenhuma porta livre entre %d e %d." % (inicial, inicial + 19))


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    porta = _porta_livre(int(args[0]) if args else 8766)
    url = f"http://127.0.0.1:{porta}/"
    srv = ThreadingHTTPServer(("127.0.0.1", porta), Handler)
    print(f"Dashboard em {url}  (feche esta janela para encerrar)")
    if "--sem-navegador" not in sys.argv:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    srv.serve_forever()
